package mezz.jei.network;

public interface IPacketId {
	int ordinal();
}
