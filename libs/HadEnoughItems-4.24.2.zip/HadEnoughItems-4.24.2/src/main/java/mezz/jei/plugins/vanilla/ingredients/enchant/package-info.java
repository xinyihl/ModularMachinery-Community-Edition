@ParametersAreNonnullByDefault
@FieldsAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.plugins.vanilla.ingredients.enchant;

import javax.annotation.ParametersAreNonnullByDefault;

import mcp.MethodsReturnNonnullByDefault;
import mezz.jei.util.FieldsAreNonnullByDefault;