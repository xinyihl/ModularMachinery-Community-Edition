@ParametersAreNonnullByDefault
@FieldsAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.plugins.vanilla.furnace;

import javax.annotation.ParametersAreNonnullByDefault;

import mcp.MethodsReturnNonnullByDefault;
import mezz.jei.util.FieldsAreNonnullByDefault;